from MercadoKratos import app

if __name__ == '__main__':
    """
    Inicia o aplicativo MercadoKratos no modo de depuração (debug).

    A execução do aplicativo só ocorrerá se este arquivo for executado diretamente,
    e não como um módulo importado.
    """
    app.run(debug=True)

