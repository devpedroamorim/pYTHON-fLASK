from MercadoKratos import database, login_manager
from flask_login import UserMixin


@login_manager.user_loader
def load_usuario(id_admin):
    """
    Função para carregar um usuário do sistema a partir do seu ID.

    :param id_admin: ID do administrador
    :type id_admin: int
    :return: Um objeto Loginadm correspondente ao usuário com o ID fornecido
    :rtype: Loginadm
    """
    return Loginadm.query.get(int(id_admin))


class Produto(database.Model):
    """
    Modelo de dados para os produtos do Mercado Kratos.

    :ivar id: ID do produto
    :ivar nomeProduto: Nome do produto
    :ivar categoriaProduto: Categoria do produto
    :ivar estoque: Quantidade disponível em estoque
    :ivar valor: Valor do produto
    """
    id = database.Column(database.Integer, primary_key=True)
    nomeProduto = database.Column(database.String, nullable=False)
    categoriaProduto = database.Column(database.String, nullable=False)
    estoque = database.Column(database.Integer, nullable=True)
    valor = database.Column(database.Float, nullable=False)


class Loginadm(database.Model, UserMixin):
    """
    Modelo de dados para os administradores do Mercado Kratos.

    :ivar id: ID do administrador
    :ivar login: Nome de usuário para login
    :ivar senha: Senha do administrador
    """
    id = database.Column(database.Integer, primary_key=True)
    login = database.Column(database.String, nullable=False, unique=True)
    senha = database.Column(database.String, nullable=False, unique=True)
