from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager

# Cria a instância do aplicativo Flask
app = Flask(__name__)

# Configurações do aplicativo
app.config['SECRET_KEY'] = '8e3d6133e6ceffe8c1b420a3c05db244'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sysestoque.db'

# Inicializa as extensões
database = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)

# Configurações do gerenciador de login
login_manager.login_view = 'login'
login_manager.login_message = 'Acesso restrito! Faça o login'
login_manager.login_message_category = 'alert-warning'

# Importa as rotas do aplicativo
from MercadoKratos import routers

